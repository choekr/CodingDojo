var express = require('express');
var path = require('path');
var bp = require('body-parser');

var app = express();

app.use(bp.urlencoded({extended:true}));
// app.use(bp.urlencoded());

app.use(express.static(path.join(__dirname + '/static')));
app.set('views', path.join(__dirname + '/views'));
app.set('view engine', 'ejs');

app.get('/', function(req, res){
  res.render('index');
})

app.post('/result', function(req, res){
  res.render('user_info', {data: req.body});
})

app.listen(8000, function(){
  console.log('Now listening on port 8000');
})
