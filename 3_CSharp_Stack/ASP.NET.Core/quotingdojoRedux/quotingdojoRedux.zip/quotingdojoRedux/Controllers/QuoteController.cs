using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using quotingdojoRedux.Models;
using quotingdojoRedux.Factory;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;

namespace quotingdojoRedux.Controllers
{
    public class QuoteController : Controller
    {   
        private readonly QuoteFactory quoteFactory;
        public QuoteController(QuoteFactory quote) {
            quoteFactory = quote;
        }
        // GET: /Home/
        [HttpGet]
        [Route("Add")]
        public IActionResult NewQuote()
        {
            if (HttpContext.Session.GetString("Key") != null)
            {
                ViewBag.Errors = ModelState.Values;
                return View("Add");
            }

            return RedirectToAction("Index", "User");
        }

        [HttpPost]
        [Route("quotes")]
        public IActionResult process_quote(QuoteItem NewQuote)
        {
            if (HttpContext.Session.GetString("Key") != null)
            {
                if (ModelState.IsValid)
                {
                    NewQuote.user_id = HttpContext.Session.GetString("Key");
                    quoteFactory.Add(NewQuote);
                    return RedirectToAction("Quotes");
                }
            }
            TryValidateModel(NewQuote);
            ViewBag.Errors = ModelState.Values;
            return View("Index", "User");
        }

        [HttpGet]
        [Route("quotes")]
        public IActionResult Quotes()
        {
            if (HttpContext.Session.GetString("Key") != null)
            {
                ViewBag.Quotes = quoteFactory.QuotesByUserByID();
                ViewBag.User = HttpContext.Session.GetString("Key");
                return View("Quotes");
            }  
            return RedirectToAction("Index", "User");          
        }

        [HttpGet]
        [RouteAttribute("edit/{id}")]
        public IActionResult Edit(int id)
        {
            if (HttpContext.Session.GetString("Key") != null)
            {
                // quoteFactory.QuoteById(id);
                ViewBag.Quote = quoteFactory.QuoteById(id);
                ViewBag.EditingId = id;
                return View("Edit");
            }            
            return RedirectToAction("Index", "User");
        }

        [HttpPost]
        [RouteAttribute("edit/{id}")]
        public IActionResult ConfirmEdit(string EditedQuote, int id)
        {
            quoteFactory.Edit(EditedQuote, id);
            return RedirectToAction("Quotes");            
        }

        [HttpGet]
        [Route("delete/{id}")]
        public IActionResult Del(int id)
        {
            if (HttpContext.Session.GetString("Key") != null)
            {
                quoteFactory.Delete(id);
                return RedirectToAction("Quotes");
            }            
            return RedirectToAction("Index", "User");
        }

        [HttpGet]
        [Route("logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "User");
        }

    }
}
