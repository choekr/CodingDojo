from django.shortcuts import render

# Create your views here.
def tmnt(request):
  return render(request, 'puff/index.html')

def ninja(request):
  context = {
    'hide': True
  }
  return render(request, 'puff/ninja.html', context)

def color(request, color):
  context={
    'color': color,
    'hide': False
  }
  return render(request, 'puff/ninja.html', context)
