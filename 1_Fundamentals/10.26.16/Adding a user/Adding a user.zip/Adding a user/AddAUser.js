$(document).ready(function() {

    $(':submit').click(function() {

      var first = $('.firstName').val();
          last = $('.lastName').val();
          email = $('.email').val();
          phone = $('.phone').val();

      $('table').append(`
        <tbody>
          <tr>
            <th> ${first} </th>
            <th> ${last} </th>
            <th> ${email} </th>
            <th> ${phone} </th>
          </tr>
        </tbody>`)

      return false;
  })
})
