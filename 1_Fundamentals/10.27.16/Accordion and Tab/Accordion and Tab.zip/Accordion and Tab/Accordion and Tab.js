$(document).ready(function() {
  $(function() {
    $("#accordion").accordion();
    $("#tabs").tabs();
    $("#datepicker").datepicker();
  })
})
